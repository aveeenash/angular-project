var app = angular.module("myApp", ["ngRoute","ngStorage"]);

app.config(function ($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "views/loginPage.html"
    })
    .when("/home", {

      // resolve: {
      //   "check": function ($location, $rootScope) {
      //     if(!$rootScope.loggedIn){
      //       $location.path("/");
      //     }
      //   }
      // },

      templateUrl: "views/homePage.html"
    })

    .when("/user", {
      templateUrl: "views/userPage.html"
    })


    .when("/activity", {
      templateUrl: "views/activityPage.html"
    })

    .when("/assignment", {
      templateUrl: "views/assignmentPage.html"
    })

    .otherwise({
      redirectTo: "views/loginPage.html"
    });
});

app.controller('loginCtrl', function ($scope, $location, $rootScope) {
  $scope.submit = function () {
    if ($scope.username == 'admin' && $scope.password == 'admin') {
      $rootScope.loggedIn = true;
      $location.path('/home')
    }
  };

});


app.controller('HeaderCtrl', function ($scope, $location, $rootScope) {
  function HeaderCtrl($scope) {
    $scope.header = { name: "header.html", url: "views/header.html" };
  }
})

app.directive("header", function () {
  return {
    restrict: 'A',
    templateUrl: 'views/header.html',
    scope: true,
    transclude: false,
    //controller: 'HeaderController'
  };
});

app.controller('lsCtrl', function ($scope, $localStorage) {
  $scope.dataArray = [];
  $scope.saveData = function () {
    var myObj = {
      userid: $scope.UserId,
      username: $scope.Name,
      dept: $scope.Department,
      email: $scope.Email,
      contact: $scope.Contact
    }
    $localStorage.myObj = myObj;
    $scope.loadData();
  };

  $scope.loadData = function(){
    //$scope.dataArray = [];
    $scope.myObj = $localStorage.myObj;
    //var data = $scope.myObj;
    $scope.dataArray.push($scope.myObj);
    console.log($scope.dataArray);
  }
  $scope.loadData();
})

app.controller('actCtrl', function ($scope, $localStorage) {
  $scope.actArray = [];
  $scope.saveAct = function () {
    var actObj = {
      actId: $scope.ActivityId,
      actName: $scope.ActivityName,
      tskDetail: $scope.TaskDetail
    }
    $localStorage.actObj = actObj;
    $scope.loadAct();
  };

  $scope.loadAct = function(){
    $scope.actObj = $localStorage.actObj;
    $scope.actArray.push($scope.actObj);
    console.log($scope.actArray);
  }
  $scope.loadAct();
})
